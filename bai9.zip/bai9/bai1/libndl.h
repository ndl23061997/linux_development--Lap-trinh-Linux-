int cong(int a, int b);
long nhan(int a, int b);
