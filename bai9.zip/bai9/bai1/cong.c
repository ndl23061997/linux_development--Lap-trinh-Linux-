int cong (int a, int b) {

	return a+b;
}
